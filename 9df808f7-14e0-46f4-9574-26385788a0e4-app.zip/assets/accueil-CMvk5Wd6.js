(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))o(s);new MutationObserver(s=>{for(const i of s)if(i.type==="childList")for(const a of i.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&o(a)}).observe(document,{childList:!0,subtree:!0});function r(s){const i={};return s.integrity&&(i.integrity=s.integrity),s.referrerPolicy&&(i.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?i.credentials="include":s.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function o(s){if(s.ep)return;s.ep=!0;const i=r(s);fetch(s.href,i)}})();const q={nom:"Comptoir de la Bordure",enseigne:"Avant-poste de Tessara, sous les deux soleils",livraison_gratuite_des:250,bases_desservies:["Base Aurore","Base Vigie","Base Cendre","Relais Tessara"]},x=[{id:"ouvrages",nom:"Ouvrages",description:"Chroniques, manuels de saut et recits de contrebande."},{id:"armement",nom:"Lames et armement",description:"Lames d'energie, cristaux focalisateurs et armes de poing."},{id:"reliques",nom:"Insignes et reliques",description:"Medaillons de l'Ordre, textile de vol et pieces de fouille."},{id:"modeles",nom:"Maquettes",description:"Reproductions a l'echelle des appareils de la flotte."}],L=[{reference:"LIV-OR-1",titre:"L'Ordre des Veilleurs, chronique d'une extinction",rayon:"ouvrages",auteur:"Vera Solheim",prix:32,stock:48,note:4.6,avis:214,format:"Relie, 420 pages",resume:"Comment un ordre de gardiens vieux de mille ans a disparu en une seule nuit. Reconstitue a partir des archives des quatre bases.",etiquettes:["recit","best-seller"]},{reference:"LIV-NA-4",titre:"Manuel de saut en secteur non balise",rayon:"ouvrages",auteur:"Commandant Ilan Reyes",prix:78,stock:12,note:4.9,avis:87,format:"Relie toile, 640 pages",resume:"La reference des ecoles de vol. Calcul de sauts a l'aveugle, lecture de derives, procedures d'urgence quand la carte ment.",etiquettes:["technique","reference"]},{reference:"LIV-AT-7",titre:"Atlas des mondes de la Bordure",rayon:"ouvrages",auteur:"Collectif",prix:124,stock:6,note:4.8,avis:53,format:"Grand format, 210 planches",resume:"Deux cent dix planches cartographiees, annotees par les equipages qui les ont relevees. Y compris les routes que personne n'avoue emprunter.",etiquettes:["cartographie","edition limitee"]},{reference:"LIV-CA-2",titre:"Petit traite de negociation en cantine",rayon:"ouvrages",auteur:"Anonyme",prix:19,stock:134,note:4.4,avis:662,format:"Broche, 96 pages",resume:"Quarante situations, quarante facons d'en sortir sans degainer. Ecrit par quelqu'un qui a manifestement beaucoup pratique.",etiquettes:["pratique","best-seller"]},{reference:"LIV-JO-9",titre:"Journal de bord d'un contrebandier",rayon:"ouvrages",auteur:"Non signe",prix:45,stock:0,note:4.7,avis:128,format:"Fac-simile relie",resume:"Reproduction integrale du registre retrouve a bord d'un cargo abandonne au Relais Tessara. Personne n'a jamais identifie son auteur.",etiquettes:["archive","rupture"]},{reference:"ARM-LE-1",titre:"Lame d'energie d'entrainement LE-1",rayon:"armement",prix:1450,stock:3,note:4.7,avis:91,format:"Lame bridee, garde en alliage brosse",resume:"Puissance reduite au quart. La lame marque, elle ne tranche pas. Le modele des salles d'entrainement de l'Ordre.",etiquettes:["entrainement","stock bas"]},{reference:"ARM-LE-3",titre:"Lame d'energie de service LE-3",rayon:"armement",prix:3800,stock:3,note:5,avis:47,format:"Pleine puissance, cristal monte",resume:"La piece la plus vendue du comptoir en valeur. Montage a la demande, cristal focalisateur inclus. Vente encadree.",etiquettes:["collection","stock bas","best-seller"]},{reference:"ARM-CR-5",titre:"Cristal focalisateur, taille brute",rayon:"armement",prix:890,stock:14,note:4.8,avis:66,format:"Taille brute, 4 a 6 g",resume:"Extrait des veines profondes de Base Cendre. La teinte varie d'une piece a l'autre : aucune n'est identique.",etiquettes:["piece unique"]},{reference:"ARM-BL-220",titre:"Blaster lourd BL-220",rayon:"armement",prix:640,stock:27,note:4.3,avis:318,format:"Cellule 40 tirs, crosse repliable",resume:"Lourd, lent a recharger, et redoutablement fiable. Le choix des equipages qui ne peuvent compter sur personne.",etiquettes:["terrain"]},{reference:"REL-ME-2",titre:"Medaillon de l'Ordre des Veilleurs",rayon:"reliques",prix:230,stock:9,note:4.9,avis:112,format:"Bronze ancien, 48 mm",resume:"Piece de fouille authentifiee, provenance Base Vigie. Porter ce medaillon en public reste mal vu dans certains secteurs.",etiquettes:["relique","stock bas"]},{reference:"REL-MA-7",titre:"Manteau de vol renforce MA-7",rayon:"reliques",prix:680,stock:23,note:4.7,avis:189,format:"Tailles S a XXL",resume:"Coupe reglementaire, doublure thermique amovible, capuche haute. Le vetement le plus vendu du comptoir en volume.",etiquettes:["textile","best-seller"]},{reference:"REL-EM-1",titre:"Ecusson brode des quatre bases",rayon:"reliques",prix:18,stock:340,note:4.2,avis:421,format:"Thermocollant, 80 mm",resume:"Les quatre bases sur une seule piece. Le cadeau de fin de cycle le plus offert entre equipages.",etiquettes:["collection"]},{reference:"MOD-CL-1",titre:"Maquette de chasseur leger, echelle 1/48",rayon:"modeles",prix:145,stock:31,note:4.6,avis:157,format:"142 pieces, resine",resume:"Reproduction du chasseur d'interception standard, ailes en position d'attaque. Notice de montage en francais.",etiquettes:["collection"]},{reference:"MOD-RE-6",titre:"Maquette du Relais Tessara, echelle 1/2000",rayon:"modeles",prix:390,stock:3,note:5,avis:24,format:"Edition numerotee, 480 pieces",resume:"Reproduction complete de la station, coursives interieures comprises. Serie limitee a 300 exemplaires.",etiquettes:["edition limitee","stock bas"]},{reference:"MOD-CA-3",titre:"Cartographie murale gravee",rayon:"modeles",prix:210,stock:18,note:4.4,avis:71,format:"900 x 600 mm, alliage grave",resume:"Les routes principales de la Bordure, gravees dans la masse. Les routes de contrebande n'y figurent pas.",etiquettes:["decoration"]}],M={nom:"Vega",role:"Conseillere du comptoir",accueil:"Bonjour. Je tiens l'inventaire du comptoir depuis onze cycles. Que cherchez-vous ?",suggestions:["Une lame pour debuter l'entrainement ?","Que conseillez-vous a moins de 100 credits ?","Qu'est-ce qui est en rupture au comptoir ?","Un cadeau pour un pilote en fin de cycle ?"]},n={boutique:q,rayons:x,produits:L,assistant:M},p=e=>e.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase();class ${async chercher(t){var i;const r=p(t),o=(i=r.match(/(?:moins de|sous|maximum|max)\s*(?:de\s*)?(\d+)/))==null?void 0:i[1],s=r.split(/\W+/).filter(a=>a.length>3);return n.produits.filter(a=>{if(/rupture|indisponible/.test(r))return a.stock===0;if(/stock bas|rare|limitee?/.test(r))return a.stock>0&&a.stock<10;if(o&&a.prix>=Number(o))return!1;const l=p([a.titre,a.rayon,a.auteur??"",a.format,a.resume,...a.etiquettes].join(" "));return s.length===0||s.some(u=>l.includes(u))}).slice(0,3)}}let k=new $;async function C(e){const t=await k.chercher(e);if(t.length===0)return{texte:"Je ne trouve pas de correspondance exacte dans l'inventaire. Essayez un rayon, un budget ou un usage plus large.",references:[]};const r=t.filter(a=>a.stock>0),o=r.length>0?r:t,s=o.map(a=>`${a.titre} (${a.prix.toLocaleString("fr-FR")} cr)`).join(", "),i=r.length===0?" Ces références sont actuellement en rupture.":o.some(a=>a.stock<10)?" Certaines pièces ont un stock limité.":"";return{texte:`Je vous conseille ${s}.${i}`,references:o.map(a=>a.reference)}}function _(e){let t=e>>>0;return()=>(t=Math.imul(t,1664525)+1013904223>>>0,t/4294967296)}function E(e,t){const r=_(t),o=[];for(let s=0;s<e;s+=1){const i=r()*560;o.push({x:r()*1600,y:i,r:.4+r()*1.1,o:Math.max(.05,(1-i/620)*(.25+r()*.6))})}return o}function R(){return E(190,20260921).map(e=>`<circle cx="${e.x.toFixed(1)}" cy="${e.y.toFixed(1)}" r="${e.r.toFixed(2)}" opacity="${e.o.toFixed(2)}"/>`).join("")}function w(){return`
<svg class="horizon" viewBox="0 0 1600 900" preserveAspectRatio="xMidYMax slice"
     xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
  <defs>
    <linearGradient id="ciel" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%"   stop-color="#04060d"/>
      <stop offset="45%"  stop-color="#070b16"/>
      <stop offset="78%"  stop-color="#1b1729"/>
      <stop offset="100%" stop-color="#3d2a28"/>
    </linearGradient>

    <radialGradient id="lueurGrande" cx="50%" cy="50%" r="50%">
      <stop offset="0%"   stop-color="#ffc94a" stop-opacity="0.55"/>
      <stop offset="35%"  stop-color="#ff9d4a" stop-opacity="0.22"/>
      <stop offset="100%" stop-color="#ff7a3c" stop-opacity="0"/>
    </radialGradient>

    <radialGradient id="lueurPetite" cx="50%" cy="50%" r="50%">
      <stop offset="0%"   stop-color="#ffe6b0" stop-opacity="0.42"/>
      <stop offset="45%"  stop-color="#ffb877" stop-opacity="0.14"/>
      <stop offset="100%" stop-color="#ff9d4a" stop-opacity="0"/>
    </radialGradient>

    <linearGradient id="duneLoin" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%"   stop-color="#2a2033"/>
      <stop offset="100%" stop-color="#191428"/>
    </linearGradient>

    <linearGradient id="duneMilieu" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%"   stop-color="#1a1526"/>
      <stop offset="100%" stop-color="#100d1c"/>
    </linearGradient>
  </defs>

  <!-- ciel -->
  <rect width="1600" height="900" fill="url(#ciel)"/>

  <!-- etoiles -->
  <g fill="#eef2f8">${R()}</g>

  <!-- halos : le grand soleil se couche, le petit le suit -->
  <circle cx="1060" cy="600" r="420" fill="url(#lueurGrande)"/>
  <circle cx="1268" cy="572" r="240" fill="url(#lueurPetite)"/>

  <!-- disques solaires, partiellement avales par l'horizon -->
  <circle cx="1060" cy="600" r="74" fill="#ffc06a" opacity="0.92"/>
  <circle cx="1268" cy="572" r="34" fill="#ffe0a8" opacity="0.82"/>

  <!-- dunes lointaines -->
  <path d="M0 612 C 190 574, 360 606, 520 590 C 700 572, 860 616, 1010 600
           C 1180 582, 1330 618, 1460 602 L1600 612 L1600 900 L0 900 Z"
        fill="url(#duneLoin)" opacity="0.9"/>

  <!-- ligne de crete, effleuree par la lumiere -->
  <path d="M0 612 C 190 574, 360 606, 520 590 C 700 572, 860 616, 1010 600
           C 1180 582, 1330 618, 1460 602 L1600 612"
        fill="none" stroke="#ffc94a" stroke-width="1.1" opacity="0.3"/>

  <!-- dunes intermediaires -->
  <path d="M0 704 C 230 664, 430 708, 650 686 C 880 662, 1090 710, 1310 690
           L1600 700 L1600 900 L0 900 Z"
        fill="url(#duneMilieu)"/>

  <!-- avant-poste : quelques masses basses et un mat -->
  <g opacity="0.78" fill="#0a0812">
    <path d="M232 686 h96 v-30 a48 22 0 0 0 -96 0 Z"/>
    <path d="M344 690 h58 v-19 a29 13 0 0 0 -58 0 Z"/>
    <rect x="292" y="606" width="2.4" height="52"/>
    <circle cx="293" cy="602" r="3.4"/>
  </g>
  <circle cx="293" cy="602" r="3.4" fill="#ffc94a" opacity="0.75"/>

  <!-- dune de premier plan -->
  <path d="M0 800 C 280 760, 540 806, 820 786 C 1100 764, 1360 808, 1600 792
           L1600 900 L0 900 Z"
        fill="#07050e"/>
</svg>`.trim()}const m={ouvrages:`
    <path d="M42 30c17-7 34-5 46 4v60c-12-9-29-11-46-4z"/>
    <path d="M88 34c12-9 29-11 46-4v60c-17-7-34-5-46 4z"/>
    <path d="M51 45c10-3 19-2 27 2M51 58c10-3 19-2 27 2M98 47c8-4 17-5 27-2M98 60c8-4 17-5 27-2"/>
    <circle cx="88" cy="111" r="5" fill="var(--ambre, #ffc94a)" stroke="none"/>`,armement:`
    <path d="M47 105 99 53M39 113l8-8 10 10-8 8zM96 56l12-12"/>
    <path d="M104 48 126 26" stroke="var(--ambre, #ffc94a)" stroke-width="7"/>
    <path d="m79 81 18 18M71 103l10 10M108 83l17 5-5 17-17-5z"/>
    <circle cx="114" cy="94" r="4" fill="var(--ambre, #ffc94a)" stroke="none"/>`,reliques:`
    <path d="M62 25c0 19 8 30 26 37 18-7 26-18 26-37"/>
    <circle cx="88" cy="88" r="29"/>
    <path d="m88 69 6 12 13 2-10 10 3 14-12-7-12 7 3-14-10-10 13-2z" stroke="var(--ambre, #ffc94a)"/>
    <path d="M62 25c10 7 42 7 52 0"/>
    <circle cx="88" cy="25" r="4" fill="var(--ambre, #ffc94a)" stroke="none"/>`,modeles:`
    <path d="M88 25 75 66 37 83l38 10 13 34 13-34 38-10-38-17z"/>
    <path d="m75 66 13 11 13-11M75 93l13-8 13 8"/>
    <path d="M51 112h74M59 120h58" opacity=".55"/>
    <circle cx="88" cy="83" r="4" fill="var(--ambre, #ffc94a)" stroke="none"/>`};function A(e,t){const r=m[e]??m.reliques;return`<svg class="produit__illustration" viewBox="0 0 176 148" role="img" aria-label="Illustration de ${T(t)}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${r}</svg>`}function T(e){return e.replace(/[&<>"]/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[t]??t)}const c={rayon:"tous",recherche:"",panier:0},h=document.querySelector("#app");if(!h)throw new Error("Le conteneur de l'application est introuvable.");const y=e=>`${e.toLocaleString("fr-FR")} cr`,B=e=>{var t;return((t=n.rayons.find(r=>r.id===e))==null?void 0:t.nom)??e};h.innerHTML=`
	<div class="scene" aria-hidden="true">${w()}</div>
	<header class="entete">
		<a class="marque" href="#catalogue" aria-label="Comptoir de la Bordure, accueil">
			<span class="marque__sceau" aria-hidden="true">CB</span>
			<span><strong>${n.boutique.nom}</strong><small>${n.boutique.enseigne}</small></span>
		</a>
		<nav class="navigation" aria-label="Navigation principale">
			<a href="#catalogue">Catalogue</a>
			<a href="#vega">Conseil</a>
			<button class="panier" type="button" aria-label="Voir le panier">Panier <span id="compteur-panier">0</span></button>
		</nav>
	</header>

	<main>
		<section class="accroche" aria-labelledby="titre-principal">
			<div class="accroche__contenu">
				<p class="sur-titre">Approvisionnement des mondes éloignés</p>
				<h1 id="titre-principal">L’équipement juste.<br><em>Au bout de la route.</em></h1>
				<p class="accroche__texte">Ouvrages de bord, pièces de terrain et objets de mémoire. Chaque référence est contrôlée au comptoir de Tessara.</p>
				<a class="action-principale" href="#catalogue">Parcourir l’inventaire <span aria-hidden="true">↓</span></a>
			</div>
			<dl class="accroche__reperes">
				<div><dt>Références</dt><dd>${n.produits.length}</dd></div>
				<div><dt>Bases desservies</dt><dd>${n.boutique.bases_desservies.length}</dd></div>
				<div><dt>Franco de port</dt><dd>${y(n.boutique.livraison_gratuite_des)}</dd></div>
			</dl>
		</section>

		<section class="comptoir" id="catalogue" aria-labelledby="titre-catalogue">
			<div class="catalogue">
				<div class="section-titre">
					<div><p class="sur-titre">Inventaire en direct</p><h2 id="titre-catalogue">Le catalogue</h2></div>
					<label class="recherche"><span>Rechercher</span><input id="recherche" type="search" placeholder="Titre, usage, référence…" autocomplete="off"></label>
				</div>
				<div class="filtres" role="group" aria-label="Filtrer par rayon">
					<button class="filtre est-actif" type="button" data-rayon="tous">Tout voir</button>
					${n.rayons.map(e=>`<button class="filtre" type="button" data-rayon="${e.id}">${e.nom}</button>`).join("")}
				</div>
				<p class="resultats" id="resultats" role="status" aria-live="polite"></p>
				<div class="grille-produits" id="grille-produits"></div>
			</div>

			<aside class="assistant" id="vega" aria-labelledby="titre-assistant">
				<div class="assistant__entete">
					<span class="assistant__signal" aria-hidden="true"></span>
					<div><p class="sur-titre">Liaison active</p><h2 id="titre-assistant">${n.assistant.nom}</h2><p>${n.assistant.role}</p></div>
				</div>
				<div class="conversation" id="conversation" role="log" aria-live="polite" aria-relevant="additions">
					<div class="message message--assistant"><span>V</span><p>${n.assistant.accueil}</p></div>
				</div>
				<div class="suggestions" aria-label="Questions suggérées">
					${n.assistant.suggestions.slice(0,3).map(e=>`<button type="button" data-suggestion="${e}">${e}</button>`).join("")}
				</div>
				<form class="formulaire-assistant" id="formulaire-assistant">
					<label for="question">Votre demande</label>
					<div><input id="question" name="question" type="text" required placeholder="Ex. Un cadeau sous 100 cr"><button type="submit" aria-label="Envoyer la demande">Envoyer</button></div>
				</form>
			</aside>
		</section>
	</main>

	<footer><span>${n.boutique.nom}</span><span>Relais Tessara · Inventaire synchronisé</span></footer>
`;function S(e){const t=e.stock===0,r=e.stock>0&&e.stock<10,o=t?"Rupture":r?`${e.stock} en stock`:"Disponible";return`
		<article class="produit ${t?"produit--rupture":""}">
			<div class="produit__visuel">
				<span class="produit__reference">${e.reference}</span>
				${A(e.rayon,e.titre)}
				<span class="produit__stock ${t?"est-rupture":r?"est-bas":""}">${o}</span>
			</div>
			<div class="produit__corps">
				<p class="produit__rayon">${B(e.rayon)}</p>
				<h3>${e.titre}</h3>
				<p class="produit__format">${e.format}</p>
				<div class="produit__bas"><strong>${y(e.prix)}</strong><button type="button" data-ajouter="${e.reference}" ${t?"disabled":""}>${t?"Indisponible":"Ajouter"}</button></div>
			</div>
		</article>`}function d(){const e=c.recherche.toLowerCase().trim(),t=n.produits.filter(s=>{const i=c.rayon==="tous"||s.rayon===c.rayon,a=[s.titre,s.reference,s.resume,s.auteur??"",...s.etiquettes].join(" ").toLowerCase();return i&&a.includes(e)}),r=document.querySelector("#grille-produits"),o=document.querySelector("#resultats");!r||!o||(r.innerHTML=t.length?t.map(S).join(""):'<p class="aucun-resultat">Aucune référence ne correspond. Essayez un autre rayon.</p>',o.textContent=`${t.length} référence${t.length>1?"s":""} affichée${t.length>1?"s":""}`)}document.querySelectorAll("[data-rayon]").forEach(e=>e.addEventListener("click",()=>{c.rayon=e.dataset.rayon??"tous",document.querySelectorAll("[data-rayon]").forEach(t=>t.classList.toggle("est-actif",t===e)),d()}));var f;(f=document.querySelector("#recherche"))==null||f.addEventListener("input",e=>{c.recherche=e.currentTarget.value,d()});var v;(v=document.querySelector("#grille-produits"))==null||v.addEventListener("click",e=>{const t=e.target.closest("[data-ajouter]");if(!t)return;c.panier+=1;const r=document.querySelector("#compteur-panier");r&&(r.textContent=String(c.panier)),t.textContent="Ajouté",window.setTimeout(()=>{t.textContent="Ajouter"},900)});async function b(e){const t=document.querySelector("#conversation");if(!t)return;t.insertAdjacentHTML("beforeend",`<div class="message message--client"><p>${j(e)}</p></div>`);const r=document.createElement("div");r.className="message message--assistant message--attente",r.innerHTML="<span>V</span><p>Consultation de l’inventaire…</p>",t.append(r),t.scrollTop=t.scrollHeight;const o=await C(e);r.remove();const s=document.createElement("div");s.className="message message--assistant",s.innerHTML="<span>V</span><p></p>",t.append(s);const i=`${o.texte}${o.references.length?` Réf. ${o.references.join(" · ")}`:""}`,a=s.querySelector("p");for(const l of i.split(" "))a&&(a.textContent+=`${l} `),await new Promise(u=>window.setTimeout(u,22));t.scrollTop=t.scrollHeight}var g;(g=document.querySelector("#formulaire-assistant"))==null||g.addEventListener("submit",e=>{e.preventDefault();const t=document.querySelector("#question");if(!(t!=null&&t.value.trim()))return;const r=t.value.trim();t.value="",b(r)});document.querySelectorAll("[data-suggestion]").forEach(e=>e.addEventListener("click",()=>{b(e.dataset.suggestion??"")}));function j(e){return e.replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"})[t]??t)}d();
